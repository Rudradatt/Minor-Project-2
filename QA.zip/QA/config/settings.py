import os
from dotenv import load_dotenv

load_dotenv()

class Settings:
    SECRET_KEY = os.getenv("SECRET_KEY", "dev-secret")
    GROQ_API_KEY = os.getenv("GROQ_API_KEY")
    DB_PATH = os.getenv("DB_PATH", "instance/robot_qa.db")
    PDF_FOLDER = "data/pdfs"
    INDEX_FOLDER = "data/index"
    GROQ_MODEL = "llama-3.1-8b-instant"
    WHISPER_MODEL = "whisper-large-v3"


settings = Settings()
