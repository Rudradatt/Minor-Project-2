import sqlite3 
import os
from config.settings import settings

def init_db():
    os.makedirs(os.path.dirname(settings.DB_PATH), exist_ok=True)

    conn = sqlite3.connect(settings.DB_PATH)
    cur = conn.cursor()

    cur.execute(
        """
        CREATE TABLE IF NOT EXISTS pdfs (
            filename TEXT PRIMARY KEY,
            hash TEXT NOT NULL,
            last_processed TIMESTAMP DEFAULT CURRENT_TIMESTAMP    
        )
        """
    )

    cur.execute(
        """
        CREATE TABLE IF NOT EXISTS index_status (
            id INTEGER PRIMARY KEY,
            last_updated TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
        """
    )

    conn.commit()
    conn.close()


def get_pdf_hashes_from_db() -> dict[str, str]:
    conn = sqlite3.connect(settings.DB_PATH)
    cur = conn.cursor()
    cur.execute("SELECT filename, hash FROM pdfs")

    rows = cur.fetchall()
    conn.close()

    return {fn: h for fn, h in rows}

def update_pdf_in_db(filename: str, file_hash: str):
    conn = sqlite3.connect(settings.DB_PATH)
    cur = conn.cursor()

    cur.execute(
        "INSERT OR REPLACE INTO pdfs (filename, hash) VALUES (?, ?)",
        (filename, file_hash)
    )

    conn.commit()
    conn.close()


def clear_pdfs_in_db():
    conn = sqlite3.connect(settings.DB_PATH)

    cur = conn.cursor()

    cur.execute("DELETE FROM pdfs")
    conn.commit()
    conn.close()


def has_index_in_db() -> bool:
    conn = sqlite3.connect(settings.DB_PATH)

    cur = conn.cursor()

    cur.execute("SELECT COUNT(*) FROM index_status")

    cnt = cur.fetchone()[0]
    conn.close()

    return cnt > 0

def update_index_status_in_db():
    conn = sqlite3.connect(settings.DB_PATH)
    cur  = conn.cursor()

    cur.execute(
        "INSERT OR REPLACE INTO index_status (id, last_updated) VALUES (1, CURRENT_TIMESTAMP)"
    )

    conn.commit()
    conn.close()