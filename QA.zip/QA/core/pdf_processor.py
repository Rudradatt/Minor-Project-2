import os
import hashlib
import pdfplumber
# from typing import  List, Tuple
from langchain.text_splitter import RecursiveCharacterTextSplitter
from core.database import get_pdf_hashes_from_db, update_pdf_in_db, clear_pdfs_in_db, has_index_in_db, update_index_status_in_db

text_splitter = RecursiveCharacterTextSplitter(chunk_size=1000, chunk_overlap=200)

def get_file_hash(path: str) -> str:
    sha = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(4096), b""):
            sha.update(chunk)
    return sha.hexdigest()

def load_and_split_pdfs(pdf_folder: str) -> tuple[list[str], list[dict]]:
    """
    Returns (chunks, metadata_list) — metadata_list[i] corresponds to chunk i.
    metadata dict includes pdf filename and page number.
    """
    page_texts = []
    metadata = []
    for fname in os.listdir(pdf_folder):
        if not fname.lower().endswith(".pdf"):
            continue
        path = os.path.join(pdf_folder, fname)
        with pdfplumber.open(path) as pdf:
            for pno, page in enumerate(pdf.pages, start=1):
                text = page.extract_text() or ""
                if text.strip():
                    page_texts.append((fname, pno, text))

    # Join texts for splitting
    full_text = " ".join([t for _, _, t in page_texts])
    chunks = text_splitter.split_text(full_text)

    # Map chunk → metadata via approximate alignment
    # (This is heuristic; you could do more precise mapping)
    metadata_list = []
    char_cursor = 0
    texts = [t for _, _, t in page_texts]
    cum_bounds = []
    cum = 0
    for (fname, pno, txt) in page_texts:
        start = cum
        cum += len(txt)
        cum_bounds.append((start, cum, fname, pno))

    for chunk in chunks:
        # find where this chunk would lie
        # naive: search substring start
        pos = full_text.find(chunk, char_cursor)
        if pos < 0:
            pos = char_cursor
        char_cursor = pos + len(chunk)
        # find which page bound covers pos
        meta = {"pdf": None, "page": None}
        for st, ed, fname, pno in cum_bounds:
            if st <= pos < ed:
                meta["pdf"] = fname
                meta["page"] = pno
                break
        if meta["pdf"] is None:
            meta["pdf"] = "unknown"
            meta["page"] = -1
        metadata_list.append(meta)

    return chunks, metadata_list

def check_and_build_index(
    pdf_folder: str, index_folder: str, build_index_fn
) -> tuple[bool, str]:
    """
    Compares current pdf folder contents to DB hashes.
    If index exists and unchanged, return (True, msg).
    Else, rebuild by calling build_index_fn, update DBs.
    build_index_fn should take chunks and metadata, and return (index, chunks, metadata)
    """
    current = {}
    for fname in os.listdir(pdf_folder):
        if fname.lower().endswith(".pdf"):
            path = os.path.join(pdf_folder, fname)
            current[fname] = get_file_hash(path)

    stored = get_pdf_hashes_from_db()

    unchanged = (
        has_index_in_db()
        and set(current.keys()) == set(stored.keys())
        and all(current[f] == stored[f] for f in current)
    )

    if unchanged:
        return False, "No changes, skip rebuild"

    # else rebuild
    chunks, metadata = load_and_split_pdfs(pdf_folder)
    if not chunks:
        return False, "No readable text in PDFs"

    index = build_index_fn(chunks, metadata)

    # update DB
    clear_pdfs_in_db()
    for fname, h in current.items():
        update_pdf_in_db(fname, h)
    update_index_status_in_db()

    return True, "Index rebuilt"
