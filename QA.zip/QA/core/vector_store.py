
import os
import pickle
import faiss
import numpy as np
# from typing import tuple

def save_index_and_meta(index: faiss.Index, chunks: list[str], metadata: list[dict], index_folder: str):
    os.makedirs(index_folder, exist_ok=True)
    faiss.write_index(index, os.path.join(index_folder, "faiss_index.index"))
    with open(os.path.join(index_folder, "chunks.pkl"), "wb") as f:
        pickle.dump(chunks, f)
    with open(os.path.join(index_folder, "metadata.pkl"), "wb") as f:
        pickle.dump(metadata, f)

def load_index_and_meta(index_folder: str) -> tuple[faiss.Index, list[str], list[dict]]:
    idx = faiss.read_index(os.path.join(index_folder, "faiss_index.index"))
    with open(os.path.join(index_folder, "chunks.pkl"), "rb") as f:
        chunks = pickle.load(f)
    with open(os.path.join(index_folder, "metadata.pkl"), "rb") as f:
        meta = pickle.load(f)
    return idx, chunks, meta

def build_faiss_index(embeddings: np.ndarray) -> faiss.Index:
    dim = embeddings.shape[1]
    num = embeddings.shape[0]
    if num < 10:
        return faiss.IndexFlatL2(dim)
    # Use IVF indexing
    nlist = min(100, max(1, num // 2))
    quant = faiss.IndexFlatL2(dim)
    index = faiss.IndexIVFFlat(quant, dim, nlist)
    index.train(embeddings)
    return index
