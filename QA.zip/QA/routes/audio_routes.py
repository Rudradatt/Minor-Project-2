# routes/audio_routes.py

from flask import Blueprint, request, redirect, url_for, flash, session
from config.settings import settings
from groq import Groq  # assuming Groq SDK supports audio
from langchain_pipeline.qa_chain import build_qa_chain
from langchain_pipeline.retriever import load_retriever
from langchain_groq import ChatGroq
from langchain.chains import RetrievalQA
from langchain_pipeline.init_langchain import get_chain

# llm = ChatOpenAI(model_name="gpt-4o-mini")  # or any you use
# llm = ChatGroq(
#     model = settings.GROQ_MODEL
# )
# qa_chain = RetrievalQA.from_chain_type(llm=llm, retriever=retriever)

bp = Blueprint("audio", __name__)

@bp.route("/ask_audio", methods=["POST"])
def ask_audio():
    if "audio" not in request.files:
        flash("No audio file", "error")
        return redirect(url_for("main.index"))

    audio = request.files["audio"]
    data = audio.read()
    if not data:
        flash("Empty audio", "error")
        return redirect(url_for("main.index"))

    client = Groq(api_key=settings.GROQ_API_KEY)
    try:
        trans = client.audio.transcriptions.create(
            model=settings.WHISPER_MODEL,
            file=("audio.webm", data, "audio/webm")
        )
        qtext = trans.text.strip()
    except Exception as e:
        flash(f"Transcription failed: {e}", "error")
        return redirect(url_for("main.index"))

    if not qtext:
        flash("Could not transcribe", "error")
        return redirect(url_for("main.index"))

    # retriever = load_retriever()
    # qa_chain = build_qa_chain(retriever)
    llm, retriever = get_chain()
    result = qa_chain.invoke({"input": qtext})
    answer = result.get("result")
    session["question"] = qtext
    session["answer"] = answer
    flash("Audio question answered", "success")
    return redirect(url_for("main.index"))
