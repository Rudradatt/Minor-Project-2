# routes/main_routes.py

from flask import Blueprint, render_template, request, redirect, url_for, flash, session
from core.database import init_db
from core.pdf_processor import check_and_build_index, load_and_split_pdfs
from langchain_pipeline.retriever import build_retriever_from_raw, load_retriever
from langchain_pipeline.qa_chain import build_qa_chain
from config.settings import settings

from langchain_pipeline.init_langchain import get_chain

bp = Blueprint("main", __name__)

# At startup, check and build index
chunks_meta_built = False
retriever = None
qa_chain = None

@bp.before_app_request
def setup():
    global retriever, qa_chain, chunks_meta_built

    init_db()
    # Rebuild index if needed
    rebuilt, msg = check_and_build_index(
        settings.PDF_FOLDER,
        settings.INDEX_FOLDER,
        lambda chunks, meta: None  # We'll build retriever below
    )

    # Always load or build
    # Load the chunks & metadata
    chunks, metadata = load_and_split_pdfs(settings.PDF_FOLDER)
    retriever = build_retriever_from_raw(chunks, metadata)
    qa_chain = build_qa_chain(retriever)
    chunks_meta_built = True

@bp.route("/", methods=["GET", "POST"])
def index():
    if request.method == "POST":
        q = request.form.get("question")
        if not q or not q.strip():
            flash("Enter a valid question.", "error")
            return redirect(url_for("main.index"))
        result = qa_chain.invoke({"input": q})
        answer = result.get("result")
        session["question"] = q
        session["answer"] = answer
        print(answer)
        flash("Answered successfully", "success")
        return redirect(url_for("main.index"))

    return render_template(
        "index.html",
        question=session.get("question"),
        answer=session.get("answer"),
    )
