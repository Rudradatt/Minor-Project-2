# app.py

from flask import Flask
from config.settings import settings
from routes.main_routes import bp as main_bp
from routes.audio_routes import bp as audio_bp

def create_app():
    app = Flask(__name__, static_folder="static", template_folder="templates")
    app.secret_key = settings.SECRET_KEY
    app.register_blueprint(main_bp)
    app.register_blueprint(audio_bp)
    return app

if __name__ == "__main__":
    app = create_app()
    app.run(debug=True, host="0.0.0.0", port=5000)
