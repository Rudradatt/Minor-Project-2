# langchain_pipeline/graph_agent.py

from langgraph.graph import Graph, START
from langgraph.prebuilt import create_react_agent
from langchain_pipeline.retriever import load_retriever
from langchain_pipeline.qa_chain import build_qa_chain
from config.settings import settings

def build_lab_assistant_graph():
    # Load retriever (or build if needed)
    retriever = load_retriever()
    qa_chain = build_qa_chain(retriever)

    # Create a ReAct-style agent using the QA chain as a tool
    agent = create_react_agent(
        model=f"groq:{settings.GROQ_MODEL}",
        tools=[qa_chain],
        prompt="You are a lab assistant robot. Answer based on documents."
    )

    graph = Graph()
    # Start node
    graph.add_node(START, agent)
    # You can add edges, memory nodes, etc. For a simple graph, start → agent → output
    return graph
