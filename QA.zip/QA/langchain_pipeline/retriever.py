# langchain_pipeline/retriever.py

from langchain_community.embeddings import SentenceTransformerEmbeddings
from langchain_community.vectorstores import FAISS
from langchain.schema import Document
from core.vector_store import load_index_and_meta, save_index_and_meta
from core.vector_store import build_faiss_index
import numpy as np
from config.settings import settings

embeddings = SentenceTransformerEmbeddings(model_name="all-MiniLM-L6-v2")

def build_retriever_from_raw(chunks: list[str], metadata: list[dict]):
    """
    Build a retriever by embedding chunks, building index, and returning retriever.
    """
    
    # Create Document objects
    docs = [Document(page_content=chunk, metadata=meta) for chunk, meta in zip(chunks, metadata)]
    vectorstore = FAISS.from_documents(docs, embeddings)
    # Save local for reloading
    vectorstore.save_local(settings.INDEX_FOLDER)
    return vectorstore.as_retriever(search_kwargs={"k": 5})

def load_retriever():
    """
    Load existing FAISS index + metadata from disk and return a retriever.
    """
    vectorstore = FAISS.load_local(
        settings.INDEX_FOLDER,
        embeddings,
        allow_dangerous_deserialization=True  # ✅ Allow trusted local pickle
    )
    return vectorstore.as_retriever(search_kwargs={"k": 5})
