# langchain_pipeline/init_langchain.py
from langchain_groq import ChatGroq
from langchain_community.vectorstores import FAISS
from langchain_community.embeddings import SentenceTransformerEmbeddings

from config.settings import settings

_qa_chain = None
_retriever = None

def get_chain():
    global _qa_chain, _retriever
    if _qa_chain is None:
        print("🔄 Initializing LangChain components...")
        embeddings = SentenceTransformerEmbeddings(model_name="all-MiniLM-L6-v2")
        vectorstore = FAISS.load_local("index", embeddings, allow_dangerous_deserialization=True)
        _retriever = vectorstore.as_retriever()
        llm = ChatGroq(model=settings.GROQ_MODEL)
        _qa_chain = (llm, _retriever)
        print("✅ LangChain initialized!")
    return _qa_chain
