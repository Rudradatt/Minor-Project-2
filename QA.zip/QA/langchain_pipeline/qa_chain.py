from langchain_core.prompts import PromptTemplate
from langchain.chains.combine_documents import create_stuff_documents_chain
from langchain.chains import create_retrieval_chain

def build_qa_chain(retriever):
    # Your LLM setup here (Groq, OpenAI, etc.)
    from langchain_groq import ChatGroq
    import os

    llm = ChatGroq(model="llama-3.1-8b-instant", api_key=os.getenv("GROQ_API_KEY"))

    # ✅ Define proper prompt with {context} and {question}
    prompt = PromptTemplate(
        input_variables=["context", "input"],
        template=(
            "You are a helpful lab assistant robot answering questions based on lab documents.\n"
            "Use the context provided to answer clearly.\n\n"
            "Context:\n{context}\n\n"
            "Question: {input}\n\n"
            "Answer:"
        )
    )

    combine_chain = create_stuff_documents_chain(llm, prompt)
    qa_chain = create_retrieval_chain(retriever, combine_chain)
    return qa_chain
